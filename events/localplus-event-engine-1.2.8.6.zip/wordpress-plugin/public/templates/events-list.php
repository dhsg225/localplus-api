<?php
/**
 * Default Events List Template
 * 
 * This template can be overridden in your theme:
 * /themes/yourtheme/localplus/events-list.php
 * 
 * @package LocalPlus_Event_Engine
 */

if (!defined('ABSPATH')) {
    exit;
}

// Extract events from template variables
$events = isset($events) ? $events : array();
$atts = isset($atts) ? $atts : array();
$display_style = isset($atts['display']) ? $atts['display'] : 'grid';
$display_method = isset($atts['display_method']) ? $atts['display_method'] : 'slide-down';
$columns = isset($atts['columns']) ? intval($atts['columns']) : 0; // 0 = auto (responsive)

// Backward compatibility
if (isset($atts['modal']) && $atts['modal'] === 'false' && $display_method === 'slide-down') {
    $display_method = 'none';
} elseif (isset($atts['modal']) && $atts['modal'] === 'true' && $display_method === 'slide-down') {
    $display_method = 'lightbox';
}
// Support old 'eventcard' name for backward compatibility
if ($display_method === 'eventcard') {
    $display_method = 'slide-down';
}

// Load formatter
require_once LOCALPLUS_EVENTS_PLUGIN_DIR . 'includes/class-event-formatter.php';
?>

<div class="localplus-events-list localplus-events-<?php echo esc_attr($display_style); ?>" data-display-method="<?php echo esc_attr($display_method); ?>"<?php if ($columns > 0) : ?> data-columns="<?php echo esc_attr($columns); ?>" style="--localplus-columns: <?php echo esc_attr($columns); ?>;"<?php endif; ?>>
    <?php if (empty($events)) : ?>
        <div class="localplus-events-empty">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p><?php esc_html_e('No events found.', 'localplus-events'); ?></p>
        </div>
    <?php else : ?>
        <div class="localplus-events-container">
            <?php foreach ($events as $event) : 
                // Format date/time
                $datetime = LocalPlus_Event_Formatter::format_datetime(
                    $event['start_time'], 
                    $event['end_time'],
                    $event['timezone_id'] ?? null
                );
                
                // Check if upcoming
                $is_upcoming = LocalPlus_Event_Formatter::is_upcoming($event['start_time']);
                
                // Get location
                $location = !empty($event['venue_area']) ? $event['venue_area'] : ($event['location'] ?? '');
                
                // Store full event data for interactions
                $event_json = htmlspecialchars(json_encode($event), ENT_QUOTES, 'UTF-8');
                
                // Determine click behavior class
                $click_class = '';
                if ($display_method === 'lightbox') {
                    $click_class = 'localplus-event-lightbox';
                } elseif ($display_method === 'slide-down' || $display_method === 'eventcard') {
                    $click_class = 'localplus-event-card-toggle';
                } elseif ($display_method === 'tooltip') {
                    $click_class = 'localplus-event-tooltip-trigger';
                } elseif ($display_method === 'singlepage') {
                    $click_class = 'localplus-event-link';
                }
            ?>
                <article class="localplus-event-card <?php echo esc_attr($click_class); ?>" 
                         data-event-id="<?php echo esc_attr($event['id']); ?>" 
                         data-status="<?php echo esc_attr($event['status']); ?>"
                         data-event-data="<?php echo esc_attr($event_json); ?>">
                    
                    <div class="localplus-event-image-wrapper">
                        <?php if (!empty($event['hero_image_url'])) : ?>
                            <img 
                                src="<?php echo esc_url($event['hero_image_url']); ?>" 
                                alt="<?php echo esc_attr($event['title']); ?>"
                                class="localplus-event-image"
                                loading="lazy"
                                onerror="this.onerror=null; this.src='data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"400\" height=\"200\" viewBox=\"0 0 400 200\"><rect width=\"400\" height=\"200\" fill=\"#f0f0f0\"/><text x=\"50%\" y=\"50%\" text-anchor=\"middle\" dy=\".3em\" font-family=\"Arial\" font-size=\"14\" fill=\"#999\">No Image</text></svg>'); ?>';"
                            >
                        <?php else : ?>
                            <div class="localplus-event-image-placeholder">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($is_upcoming) : ?>
                            <span class="localplus-event-badge localplus-event-badge-upcoming">
                                <?php esc_html_e('Upcoming', 'localplus-events'); ?>
                            </span>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['event_type']) && $event['event_type'] !== 'general') : ?>
                            <span class="localplus-event-badge localplus-event-badge-category">
                                <?php echo esc_html(ucfirst($event['event_type'])); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="localplus-event-content">
                        <header class="localplus-event-header">
                            <h3 class="localplus-event-title">
                                <?php if ($display_method === 'singlepage') : ?>
                                    <a href="<?php echo esc_url(get_permalink() . '?event_id=' . $event['id']); ?>" class="localplus-event-title-link">
                                        <?php echo esc_html($event['title']); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo esc_html($event['title']); ?>
                                <?php endif; ?>
                            </h3>
                            
                            <?php if (!empty($event['subtitle']) && $display_style !== 'compact') : ?>
                                <p class="localplus-event-subtitle">
                                    <?php echo esc_html($event['subtitle']); ?>
                                </p>
                            <?php endif; ?>
                        </header>
                        
                        <!-- Compact inline meta layout -->
                        <div class="localplus-event-meta-compact">
                            <span class="localplus-meta-inline">
                                <svg class="localplus-icon-inline" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <span><?php echo esc_html($datetime['date']); ?> • <?php echo esc_html($datetime['time']); ?></span>
                            </span>
                            <?php if (!empty($location)) : ?>
                                <span class="localplus-meta-inline">
                                    <svg class="localplus-icon-inline" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                                        <circle cx="12" cy="10" r="3" />
                                    </svg>
                                    <span><?php echo esc_html($location); ?></span>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!empty($event['description']) && $display_style !== 'compact') : ?>
                            <div class="localplus-event-description">
                                <?php echo esc_html(wp_trim_words($event['description'], 20)); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($display_method === 'slide-down' || $display_method === 'eventcard') : ?>
                            <div class="localplus-event-more">
                                <span><?php esc_html_e('View Details', 'localplus-events'); ?> ↓</span>
                            </div>
                        <?php elseif ($display_method === 'lightbox') : ?>
                            <div class="localplus-event-more">
                                <span><?php esc_html_e('View Details', 'localplus-events'); ?> →</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Slide-down panel -->
                    <?php if ($display_method === 'slide-down' || $display_method === 'eventcard') : ?>
                    <div class="localplus-event-details-panel">
                        <div class="localplus-event-details-content">
                            <?php if (!empty($event['hero_image_url'])) : ?>
                                <div class="localplus-event-details-image">
                                    <img src="<?php echo esc_url($event['hero_image_url']); ?>" alt="<?php echo esc_attr($event['title']); ?>">
                                </div>
                            <?php endif; ?>
                            <div class="localplus-event-details-info">
                                <div class="localplus-event-details-meta">
                                    <div>
                                        <strong><?php esc_html_e('Date:', 'localplus-events'); ?></strong>
                                        <?php echo esc_html($datetime['date']); ?>
                                    </div>
                                    <div>
                                        <strong><?php esc_html_e('Time:', 'localplus-events'); ?></strong>
                                        <?php echo esc_html($datetime['time']); ?>
                                    </div>
                                    <?php if (!empty($location)) : ?>
                                        <div>
                                            <strong><?php esc_html_e('Location:', 'localplus-events'); ?></strong>
                                            <?php echo esc_html($location); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($event['description'])) : ?>
                                    <div class="localplus-event-details-description">
                                        <?php echo esc_html($event['description']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
        
        <!-- Lightbox Modal - EventOn Style -->
        <?php if ($display_method === 'lightbox') : ?>
        <!-- Modal moved to body level via JavaScript to avoid container overflow issues -->
        <!-- [2025-12-05] - Only create modal if it doesn't already exist (for multiple shortcodes on same page) -->
        <?php if (!isset($GLOBALS['localplus_event_modal_created'])) : ?>
        <?php $GLOBALS['localplus_event_modal_created'] = true; ?>
        <div class="localplus-event-modal" id="localplus-event-modal" role="dialog" aria-labelledby="localplus-modal-title" aria-hidden="true" style="display: none;">
            <div class="localplus-modal-wrapper">
                <div class="localplus-modal-wrapper-inner">
                    <div class="localplus-modal-container">
                        <button class="localplus-modal-close" aria-label="<?php esc_attr_e('Close', 'localplus-events'); ?>">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                        <div class="localplus-modal-content">
                            <div class="localplus-modal-header">
                                <div class="localplus-modal-date-badge"></div>
                                <h2 id="localplus-modal-title" class="localplus-modal-title"></h2>
                                <p class="localplus-modal-subtitle"></p>
                                <div class="localplus-modal-header-info">
                                    <div class="localplus-modal-header-info-item">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                        </svg>
                                        <span class="localplus-modal-header-time"></span>
                                    </div>
                                    <div class="localplus-modal-header-info-item">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                                            <circle cx="12" cy="10" r="3" />
                                        </svg>
                                        <span class="localplus-modal-header-location"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="localplus-modal-scrollable">
                                <div class="localplus-modal-image-wrapper">
                                    <img class="localplus-modal-image" src="" alt="">
                                </div>
                                <div class="localplus-modal-body">
                                    <div class="localplus-modal-description"></div>
                                    
                                    <div class="localplus-modal-details">
                                        <div class="localplus-modal-detail-section">
                                            <h4 class="localplus-modal-detail-title">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="12" cy="7" r="4"></circle>
                                                </svg>
                                                Organizer
                                            </h4>
                                            <div class="localplus-modal-organizer"></div>
                                        </div>
                                        
                                        <div class="localplus-modal-detail-section">
                                            <h4 class="localplus-modal-detail-title">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                                    <circle cx="12" cy="10" r="3"></circle>
                                                </svg>
                                                Map
                                            </h4>
                                            <div class="localplus-modal-map"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; // End modal creation check ?>
        <?php endif; // End lightbox display method check ?>
        
        <!-- Tooltip -->
        <?php if ($display_method === 'tooltip') : ?>
        <div class="localplus-event-tooltip" id="localplus-event-tooltip"></div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<style>
/* [2025-01-06] - Multiple display methods with fixed modal */
.localplus-events-list {
    margin: 30px 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}

/* Grid Display (Default) */
.localplus-events-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 24px;
    margin-top: 20px;
}

/* [2025-12-05] - Fixed columns support */
.localplus-events-list[data-columns] .localplus-events-container {
    grid-template-columns: repeat(var(--localplus-columns, auto-fill), minmax(320px, 1fr));
}

/* Specific column counts */
.localplus-events-list[data-columns="1"] .localplus-events-container {
    grid-template-columns: 1fr;
}

.localplus-events-list[data-columns="2"] .localplus-events-container {
    grid-template-columns: repeat(2, 1fr);
}

.localplus-events-list[data-columns="3"] .localplus-events-container {
    grid-template-columns: repeat(3, 1fr);
}

.localplus-events-list[data-columns="4"] .localplus-events-container {
    grid-template-columns: repeat(4, 1fr);
}

.localplus-events-list[data-columns="5"] .localplus-events-container {
    grid-template-columns: repeat(5, 1fr);
}

.localplus-events-list[data-columns="6"] .localplus-events-container {
    grid-template-columns: repeat(6, 1fr);
}

/* Responsive: columns parameter still respects mobile breakpoint */
@media (max-width: 768px) {
    .localplus-events-list[data-columns] .localplus-events-container {
        grid-template-columns: 1fr;
    }
}

/* List Display */
.localplus-events-list .localplus-events-list .localplus-events-container {
    grid-template-columns: 1fr;
}

.localplus-events-list .localplus-events-list .localplus-event-card {
    display: grid;
    grid-template-columns: 200px 1fr;
    gap: 20px;
}

.localplus-events-list .localplus-events-list .localplus-event-image-wrapper {
    height: 150px;
}

/* Compact Display */
.localplus-events-compact .localplus-events-container {
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 16px;
}

.localplus-events-compact .localplus-event-image-wrapper {
    height: 160px;
}

.localplus-events-compact .localplus-event-content {
    padding: 16px;
}

.localplus-events-compact .localplus-event-title {
    font-size: 1.1em;
    margin-bottom: 8px;
}

/* Detailed Display */
.localplus-events-detailed .localplus-events-container {
    grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
}

.localplus-events-detailed .localplus-event-image-wrapper {
    height: 260px;
}

@media (max-width: 768px) {
    .localplus-events-container {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .localplus-events-list .localplus-events-list .localplus-event-card {
        grid-template-columns: 1fr;
    }
}

.localplus-event-card {
    background: #ffffff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    display: flex;
    flex-direction: column;
    position: relative;
}

.localplus-event-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
}

.localplus-event-lightbox,
.localplus-event-card-toggle {
    cursor: pointer;
}

.localplus-event-image-wrapper {
    position: relative;
    width: 100%;
    height: 220px;
    overflow: hidden;
    background: #f5f5f5;
}

.localplus-event-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.localplus-event-card:hover .localplus-event-image {
    transform: scale(1.05);
}

.localplus-event-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    color: #999;
}

.localplus-event-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    z-index: 2;
}

.localplus-event-badge-upcoming {
    background: #10b981;
    color: #ffffff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.localplus-event-badge-category {
    background: rgba(0, 115, 170, 0.9);
    color: #ffffff;
    backdrop-filter: blur(4px);
    top: auto;
    bottom: 12px;
    right: 12px;
}

.localplus-event-content {
    padding: 20px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.localplus-event-header {
    margin-bottom: 12px;
}

.localplus-event-title {
    margin: 0 0 8px 0;
    font-size: 1.25em;
    font-weight: 700;
    line-height: 1.4;
    color: #1a1a1a;
}

.localplus-event-title-link {
    color: inherit;
    text-decoration: none;
}

.localplus-event-title-link:hover {
    color: #0073aa;
}

.localplus-event-subtitle {
    margin: 0;
    font-size: 0.9em;
    color: #666;
    font-weight: 400;
}

/* Compact inline meta layout */
.localplus-event-meta-compact {
    display: flex;
    flex-wrap: wrap;
    gap: 12px 16px;
    margin: 12px 0;
    font-size: 0.85em;
    color: #666;
}

.localplus-meta-inline {
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.localplus-icon-inline {
    flex-shrink: 0;
    color: #0073aa;
    opacity: 0.7;
}

.localplus-event-description {
    margin-top: 12px;
    padding-top: 12px;
    font-size: 0.9em;
    line-height: 1.6;
    color: #555;
    border-top: 1px solid #f0f0f0;
}

.localplus-event-more {
    margin-top: auto;
    padding-top: 12px;
    font-size: 0.9em;
    color: #0073aa;
    font-weight: 500;
    border-top: 1px solid #f0f0f0;
}

.localplus-event-more span {
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

/* Slide-down panel */
.localplus-event-details-panel {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
    background: #f9f9f9;
}

.localplus-event-card.active .localplus-event-details-panel {
    max-height: 1000px;
}

.localplus-event-details-content {
    padding: 20px;
}

.localplus-event-details-image {
    margin-bottom: 20px;
    border-radius: 8px;
    overflow: hidden;
}

.localplus-event-details-image img {
    width: 100%;
    height: auto;
    display: block;
}

.localplus-event-details-meta {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 20px;
    font-size: 0.95em;
}

.localplus-event-details-description {
    line-height: 1.7;
    color: #444;
}

/* Lightbox Modal - EventOn Style */
.localplus-event-modal {
    display: none;
    overflow-x: hidden;
    overflow-y: auto;
    background-color: rgba(210, 210, 210, 0.92);
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 999999;
    padding-right: 17px;
    padding-left: 17px;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.15s linear, visibility 0.15s linear;
}

.localplus-event-modal.show {
    display: block !important;
    opacity: 1;
    visibility: visible;
}

.localplus-modal-wrapper {
    display: table;
    height: 100%;
    width: 100%;
}

.localplus-modal-wrapper-inner {
    display: table-cell;
    vertical-align: middle;
    position: relative;
}

.localplus-modal-container {
    width: 100%;
    margin: 60px auto;
    max-width: 1000px;
    position: relative;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    overflow: visible; /* Changed from hidden to visible - scrollbar should be visible */
    transform: translateY(20%);
    opacity: 0;
    transition: all 0.5s ease;
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 120px);
    height: auto;
}

.localplus-event-modal.show .localplus-modal-container {
    transform: translateY(0);
    opacity: 1;
}

.localplus-modal-close {
    position: absolute;
    top: 15px;
    right: 15px;
    width: 32px;
    height: 32px;
    border: none;
    background: rgba(0, 0, 0, 0.6);
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000001;
    transition: all 0.2s ease;
    color: #ffffff;
    line-height: 1;
}

.localplus-modal-close:hover {
    background: rgba(0, 0, 0, 0.8);
    transform: scale(1.1);
}

.localplus-modal-close svg {
    width: 18px;
    height: 18px;
    stroke: currentColor;
}

.localplus-modal-content {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-height: 0;
    overflow: visible; /* Changed from hidden - allow scrollbar to show */
}

.localplus-modal-header {
    background: #0073aa;
    color: #ffffff;
    padding: 30px 50px 25px 30px;
    position: relative;
    flex-shrink: 0;
}

.localplus-modal-date-badge {
    display: inline-block;
    background: rgba(255, 255, 255, 0.25);
    padding: 6px 14px;
    border-radius: 4px;
    font-size: 0.9em;
    font-weight: 600;
    margin-bottom: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.localplus-modal-title {
    margin: 0 0 6px 0;
    font-size: 1.8em;
    font-weight: 700;
    line-height: 1.3;
    color: #ffffff;
}

.localplus-modal-subtitle {
    margin: 0 0 12px 0;
    font-size: 0.95em;
    opacity: 0.95;
    font-weight: 400;
}

.localplus-modal-header-info {
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 0.9em;
    margin-top: 12px;
}

.localplus-modal-header-info-item {
    display: flex;
    align-items: center;
    gap: 8px;
    opacity: 0.95;
}

.localplus-modal-header-info-item svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
}

.localplus-modal-scrollable {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    min-height: 0;
    max-height: 100%;
    /* EventOn-style scrollbar positioning - scrollbar on right side of content area */
    padding-right: 0;
    margin-right: 0;
}

/* Custom scrollbar styling to match EventOn */
.localplus-modal-scrollable::-webkit-scrollbar {
    width: 8px;
}

.localplus-modal-scrollable::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
}

.localplus-modal-scrollable::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 4px;
}

.localplus-modal-scrollable::-webkit-scrollbar-thumb:hover {
    background: #555;
}

.localplus-modal-image-wrapper {
    width: 100%;
    height: 350px;
    overflow: hidden;
    background: #f5f5f5;
    flex-shrink: 0;
}

.localplus-modal-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

.localplus-modal-body {
    padding: 30px;
    padding-right: 38px; /* Extra padding on right to account for scrollbar space */
}

/* Organizer and Map sections */
.localplus-modal-details {
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid #e5e5e5;
}

.localplus-modal-detail-section {
    margin-bottom: 25px;
}

.localplus-modal-detail-section:last-child {
    margin-bottom: 0;
}

.localplus-modal-detail-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 1em;
    font-weight: 600;
    color: #333;
    margin: 0 0 12px 0;
}

.localplus-modal-detail-title svg {
    flex-shrink: 0;
    color: #0073aa;
}

.localplus-modal-organizer {
    color: #555;
    font-size: 0.95em;
    line-height: 1.6;
}

.localplus-modal-map-embed {
    width: 100%;
    margin-bottom: 15px;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.localplus-modal-map-embed iframe {
    display: block;
    width: 100%;
    height: 300px;
    border: none;
}

.localplus-modal-map-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #0073aa;
    text-decoration: none;
    font-size: 0.95em;
    padding: 8px 12px;
    border: 1px solid #0073aa;
    border-radius: 4px;
    transition: all 0.2s ease;
}

.localplus-modal-map-link:hover {
    background: #0073aa;
    color: #ffffff;
}

.localplus-modal-map-link svg {
    flex-shrink: 0;
}

.localplus-modal-map-location {
    margin: 10px 0 0 0;
    color: #666;
    font-size: 0.9em;
}

.localplus-modal-map-unavailable {
    color: #999;
    font-size: 0.9em;
    font-style: italic;
}

.localplus-modal-description {
    font-size: 1em;
    line-height: 1.7;
    color: #444;
    white-space: pre-wrap;
}

/* Tooltip */
.localplus-event-tooltip {
    position: fixed; /* [2025-12-05] - Changed from absolute to fixed for proper positioning */
    background: #ffffff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    max-width: 300px;
    display: none;
    pointer-events: none;
}

.localplus-event-tooltip.active {
    display: block;
}

.localplus-events-empty {
    text-align: center;
    padding: 60px 20px;
    background: #f9f9f9;
    border-radius: 12px;
}

.localplus-events-empty svg {
    margin: 0 auto 20px;
    opacity: 0.4;
    color: #999;
}

.localplus-events-empty p {
    font-size: 16px;
    color: #666;
    margin: 0;
}

/* Body scroll lock when modal open */
body.localplus-modal-open {
    overflow: hidden !important;
    position: fixed;
    width: 100%;
    height: 100%;
}

/* Ensure modal wrapper allows scrolling */
.localplus-event-modal.show .localplus-modal-wrapper {
    overflow: visible;
}

.localplus-event-modal.show .localplus-modal-wrapper-inner {
    overflow: visible;
}
}

@media (max-width: 768px) {
    .localplus-event-modal {
        padding: 0;
    }
    
    .localplus-modal-container {
        margin: 0;
        max-width: 100%;
        max-height: 100vh;
        border-radius: 0;
    }
    
    .localplus-modal-wrapper-inner {
        vertical-align: top;
    }
    
    .localplus-modal-header {
        padding: 25px 40px 20px 20px;
    }
    
    .localplus-modal-title {
        font-size: 1.5em;
    }
    
    .localplus-modal-body {
        padding: 25px 20px;
    }
    
    .localplus-modal-image-wrapper {
        height: 250px;
    }
    
    
    .localplus-modal-scrollable {
        max-height: calc(100vh - 200px);
    }
}

@media (max-width: 500px) {
    .localplus-event-modal {
        padding: 10px;
    }
}
</style>

