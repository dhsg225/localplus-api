<?php 
/**
 * EventCard Time html content
 * @version 5.0.1
 */


$iconTime = "<span class='evcal_evdata_icons'><i class='fa ".get_eventON_icon('evcal__fai_002', 'fa-clock-o',$evOPT )."'></i></span>";
						
// time for event card
$timezone = (!empty($object->timezone)? ' <em class="evo_eventcard_tiemzone evomarl5 evoop7">'. $object->timezone.'</em>':null);

// event time
$time_content = "<span class='evo_eventcard_time_t evogap5 evofxww'>". apply_filters('evo_eventcard_time', $object->timetext. $timezone, $object) . "</span>";

// custom timezone text
if( !EVO()->cal->check_yn('evo_gmt_hide','evcal_1') && !empty($this->ev_tz) ){
	$time_content .= "<span class='evo_tz marr5'>(". $EVENT->gmt .")</span>";
}		

// Duration
if( $EVENT->echeck_yn('show_dur')){
	$time_content .= "<span class='evo_time_dur evodfx evofxdrr evofxaic evoop5'><i class='fa fa-hourglass-half evofz14i evomarr10'></i>". evo_lang('Duration') .' '.$this->help->get_human_time( $EVENT->duration ) ."</span>";
}	


// view in my time - local time
if( !empty($this->ev_tz) && EVO()->cal->check_yn('evo_show_localtime','evcal_1') ){
	

	extract( $this->timezone_data );
		
	$data = array(
		'__df'=> $__df,
		'__tf'=> $__tf,
		'__f'=> $__f,
		'times'=> $EVENT->start_unix . '-' . $EVENT->end_unix,
		'tzo' => $this->help->_get_tz_offset_seconds( $this->ev_tz,  $EVENT->start_unix)
	);
	
	//$time_content.= $this->get_view_my_time_content( $this->timezone_data , $EVENT->start_unix, $EVENT->end_unix);	

	$time_content .= "<div class='padt5'><span class='evo_btn_arr tzo_trig evo_mytime evo_hover_op6 evocard' {$this->help->array_to_html_data($data)}>". $__t  . "<i class='fa fa-chevron-right'></i></span></div>";	
}




echo "<div class='evo_metarow_time evorow evcal_evdata_row evcal_evrow_sm ".$end_row_class."'>
		{$iconTime}
		<div class='evcal_evdata_cell'>							
			<h3 class='evo_h3'>".$iconTime . evo_lang_get('evcal_lang_time','Time')."</h3><div>".$time_content."</div>
		</div>
	</div>";


//print_r($EVENT->get_prop('repeat_intervals'));