<?php
/**
 * Weekly View Template
 * 
 * Displays events in a weekly calendar grid (Sun-Sat)
 * 
 * @package LocalPlus_Event_Engine
 */

if (!defined('ABSPATH')) {
    exit;
}

// Extract events from template variables
$events = isset($events) ? $events : array();
$atts = isset($atts) ? $atts : array();

// Weekly view parameters
$start_date = isset($atts['weekly_start_date']) && !empty($atts['weekly_start_date']) 
    ? $atts['weekly_start_date'] 
    : date('Y-m-d');
$weekly_style = isset($atts['weekly_style']) ? max(1, min(3, intval($atts['weekly_style']))) : 1;

// Calculate week start (Sunday)
try {
    $week_start = new DateTime($start_date);
    $day_of_week = (int)$week_start->format('w'); // 0 = Sunday, 6 = Saturday
    $week_start->modify('-' . $day_of_week . ' days');
} catch (Exception $e) {
    $week_start = new DateTime();
    $day_of_week = (int)$week_start->format('w');
    $week_start->modify('-' . $day_of_week . ' days');
}

$week_start_str = $week_start->format('Y-m-d');
$week_end = clone $week_start;
$week_end->modify('+6 days');
$week_end_str = $week_end->format('Y-m-d');

// Generate week days
$week_days = array();
for ($i = 0; $i < 7; $i++) {
    $day = clone $week_start;
    $day->modify('+' . $i . ' days');
    $week_days[] = $day;
}

// Group events by day
$events_by_day = array();
foreach ($week_days as $day) {
    $day_str = $day->format('Y-m-d');
    $events_by_day[$day_str] = array();
    
    foreach ($events as $event) {
        $event_start = new DateTime($event['start_time']);
        $event_date = $event_start->format('Y-m-d');
        if ($event_date === $day_str) {
            $events_by_day[$day_str][] = $event;
        }
    }
}

// Load formatter
require_once LOCALPLUS_EVENTS_PLUGIN_DIR . 'includes/class-event-formatter.php';
?>

<div class="localplus-calendar-weekly localplus-weekly-style-<?php echo esc_attr($weekly_style); ?>" 
     data-week-start="<?php echo esc_attr($week_start_str); ?>"
     data-week-style="<?php echo esc_attr($weekly_style); ?>">
    
    <!-- Week Navigator -->
    <div class="localplus-weekly-navigator">
        <button class="localplus-nav-btn localplus-nav-prev-week" data-action="prev-week" aria-label="Previous week">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 18l-6-6 6-6"/>
            </svg>
        </button>
        <div class="localplus-week-range">
            <span class="localplus-week-start"><?php echo esc_html($week_start->format('M j')); ?></span>
            <span class="localplus-week-separator"> - </span>
            <span class="localplus-week-end"><?php echo esc_html($week_end->format('M j, Y')); ?></span>
        </div>
        <button class="localplus-nav-btn localplus-nav-next-week" data-action="next-week" aria-label="Next week">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 18l6-6-6-6"/>
            </svg>
        </button>
        <button class="localplus-nav-btn localplus-nav-today" data-action="today" aria-label="Go to current week">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 2v4M12 18v4M4 12H2M6.31412 6.31412L4.8999 4.8999M17.6859 6.31412L19.1001 4.8999M6.31412 17.69L4.8999 19.1042M17.6859 17.69L19.1001 19.1042M22 12H20M12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6Z"/>
            </svg>
        </button>
    </div>

    <!-- Month Navigator (if style 1) -->
    <?php if ($weekly_style == 1) : ?>
    <div class="localplus-weekly-month-nav">
        <button class="localplus-nav-btn localplus-nav-prev-month" data-action="prev-month">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 18l-6-6 6-6"/>
            </svg>
        </button>
        <div class="localplus-weekly-month-year">
            <?php echo esc_html($week_start->format('F Y')); ?>
        </div>
        <button class="localplus-nav-btn localplus-nav-next-month" data-action="next-month">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 18l6-6-6-6"/>
            </svg>
        </button>
    </div>
    <?php endif; ?>

    <!-- Week Grid -->
    <div class="localplus-weekly-grid">
        <!-- Day Headers -->
        <div class="localplus-weekly-day-header">
            <?php foreach ($week_days as $day) : 
                $day_name = $day->format('D');
                $day_num = $day->format('d');
                $is_today = $day->format('Y-m-d') === date('Y-m-d');
            ?>
                <div class="localplus-week-day-header <?php echo $is_today ? 'today' : ''; ?>">
                    <div class="localplus-week-day-name"><?php echo esc_html($day_name); ?></div>
                    <div class="localplus-week-day-number"><?php echo esc_html($day_num); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Day Cells with Events -->
        <div class="localplus-weekly-day-cells">
            <?php foreach ($week_days as $day) : 
                $day_str = $day->format('Y-m-d');
                $day_events = $events_by_day[$day_str];
                $is_today = $day_str === date('Y-m-d');
            ?>
                <div class="localplus-week-day-cell <?php echo $is_today ? 'today' : ''; ?>" data-date="<?php echo esc_attr($day_str); ?>">
                    <?php if (empty($day_events)) : ?>
                        <div class="localplus-week-no-events"><?php esc_html_e('No events', 'localplus-events'); ?></div>
                    <?php else : ?>
                        <div class="localplus-week-events">
                            <?php foreach ($day_events as $event) : 
                                $datetime = LocalPlus_Event_Formatter::format_datetime(
                                    $event['start_time'], 
                                    $event['end_time'],
                                    $event['timezone_id'] ?? null
                                );
                                $location = !empty($event['venue_area']) ? $event['venue_area'] : ($event['location'] ?? '');
                                $event_json = htmlspecialchars(json_encode($event), ENT_QUOTES, 'UTF-8');
                            ?>
                                <div class="localplus-week-event-item localplus-event-lightbox" 
                                     data-event-id="<?php echo esc_attr($event['id']); ?>"
                                     data-event-data="<?php echo esc_attr($event_json); ?>">
                                    <div class="localplus-week-event-time"><?php echo esc_html($datetime['time']); ?></div>
                                    <div class="localplus-week-event-title"><?php echo esc_html($event['title']); ?></div>
                                    <?php if (!empty($location)) : ?>
                                        <div class="localplus-week-event-location"><?php echo esc_html($location); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Lightbox Modal (shared with other views) -->
    <?php if (!isset($GLOBALS['localplus_event_modal_created'])) : ?>
    <?php $GLOBALS['localplus_event_modal_created'] = true; ?>
    <?php include LOCALPLUS_EVENTS_PLUGIN_DIR . 'public/templates/lightbox-modal.php'; ?>
    <?php endif; ?>
</div>

<style>
/* Weekly View Styles */
.localplus-calendar-weekly {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

/* Week Navigator */
.localplus-weekly-navigator {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20px;
    margin-bottom: 30px;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 12px;
}

.localplus-week-range {
    font-size: 1.2em;
    font-weight: 600;
    color: #1a1a1a;
}

.localplus-week-separator {
    margin: 0 8px;
    color: #999;
}

/* Month Navigator */
.localplus-weekly-month-nav {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin-bottom: 20px;
}

.localplus-weekly-month-year {
    font-size: 1.1em;
    font-weight: 600;
    color: #666;
}

/* Week Grid */
.localplus-weekly-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 1px;
    background: #e0e0e0;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    overflow: hidden;
}

/* Day Headers */
.localplus-weekly-day-header {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    background: #f5f5f5;
}

.localplus-week-day-header {
    padding: 15px 10px;
    text-align: center;
    background: #fff;
    border-right: 1px solid #e0e0e0;
}

.localplus-week-day-header:last-child {
    border-right: none;
}

.localplus-week-day-header.today {
    background: #e3f2fd;
    color: #1976d2;
}

.localplus-week-day-name {
    font-size: 0.85em;
    font-weight: 600;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 5px;
}

.localplus-week-day-header.today .localplus-week-day-name {
    color: #1976d2;
    font-weight: 700;
}

.localplus-week-day-number {
    font-size: 1.5em;
    font-weight: 700;
    color: #1a1a1a;
}

.localplus-week-day-header.today .localplus-week-day-number {
    color: #1976d2;
}

/* Day Cells */
.localplus-weekly-day-cells {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    min-height: 400px;
}

.localplus-week-day-cell {
    background: #fff;
    padding: 12px;
    border-right: 1px solid #e0e0e0;
    border-bottom: 1px solid #e0e0e0;
    min-height: 200px;
    position: relative;
}

.localplus-week-day-cell:last-child {
    border-right: none;
}

.localplus-week-day-cell.today {
    background: #f0f8ff;
    border-left: 3px solid #1976d2;
}

.localplus-week-no-events {
    color: #999;
    font-size: 0.85em;
    text-align: center;
    padding: 20px 0;
}

/* Week Events */
.localplus-week-events {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.localplus-week-event-item {
    background: #0073aa;
    color: #fff;
    padding: 10px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.9em;
}

.localplus-week-event-item:hover {
    background: #005a87;
    transform: translateX(2px);
    box-shadow: 0 2px 8px rgba(0, 115, 170, 0.3);
}

.localplus-week-event-time {
    font-weight: 600;
    font-size: 0.85em;
    margin-bottom: 4px;
    opacity: 0.9;
}

.localplus-week-event-title {
    font-weight: 600;
    margin-bottom: 4px;
    line-height: 1.3;
}

.localplus-week-event-location {
    font-size: 0.8em;
    opacity: 0.85;
    margin-top: 4px;
}

/* Style 2: Compact */
.localplus-weekly-style-2 .localplus-week-event-item {
    padding: 8px;
    font-size: 0.85em;
}

.localplus-weekly-style-2 .localplus-week-day-cell {
    min-height: 150px;
}

/* Style 3: Minimal */
.localplus-weekly-style-3 .localplus-week-event-item {
    background: #f5f5f5;
    color: #1a1a1a;
    border-left: 3px solid #0073aa;
}

.localplus-weekly-style-3 .localplus-week-event-item:hover {
    background: #e0e0e0;
}

/* Responsive */
@media (max-width: 768px) {
    .localplus-weekly-grid {
        grid-template-columns: 1fr;
    }
    
    .localplus-weekly-day-header {
        display: none;
    }
    
    .localplus-week-day-cell {
        border-right: none;
        border-bottom: 2px solid #e0e0e0;
        min-height: auto;
    }
    
    .localplus-week-day-cell::before {
        content: attr(data-date);
        display: block;
        font-weight: 700;
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid #e0e0e0;
    }
}
</style>

