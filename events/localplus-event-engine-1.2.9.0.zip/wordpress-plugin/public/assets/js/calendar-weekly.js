/**
 * Weekly Calendar View JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        initWeeklyView();
    });
    
    function initWeeklyView() {
        const weeklyCalendars = document.querySelectorAll('.localplus-calendar-weekly');
        
        weeklyCalendars.forEach(calendar => {
            const prevWeekBtn = calendar.querySelector('.localplus-nav-prev-week');
            const nextWeekBtn = calendar.querySelector('.localplus-nav-next-week');
            const todayBtn = calendar.querySelector('.localplus-nav-today');
            const prevMonthBtn = calendar.querySelector('.localplus-nav-prev-month');
            const nextMonthBtn = calendar.querySelector('.localplus-nav-next-month');
            
            if (prevWeekBtn) {
                prevWeekBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateWeek(calendar, -1);
                });
            }
            
            if (nextWeekBtn) {
                nextWeekBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateWeek(calendar, 1);
                });
            }
            
            if (todayBtn) {
                todayBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateToToday(calendar);
                });
            }
            
            if (prevMonthBtn) {
                prevMonthBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateMonth(calendar, -1);
                });
            }
            
            if (nextMonthBtn) {
                nextMonthBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateMonth(calendar, 1);
                });
            }
            
            // Initialize lightbox for event items
            const eventItems = calendar.querySelectorAll('.localplus-event-lightbox');
            eventItems.forEach(item => {
                if (item.dataset.lightboxInitialized !== 'true') {
                    item.dataset.lightboxInitialized = 'true';
                    item.addEventListener('click', function(e) {
                        e.preventDefault();
                        const eventData = this.dataset.eventData;
                        if (eventData) {
                            try {
                                const event = JSON.parse(eventData);
                                if (typeof openLightbox === 'function') {
                                    openLightbox(event);
                                }
                            } catch (e) {
                                console.error('LocalPlus Events: Error parsing event data:', e);
                            }
                        }
                    });
                }
            });
        });
    }
    
    function navigateWeek(calendar, direction) {
        const weekStart = calendar.dataset.weekStart;
        if (!weekStart) return;
        
        const date = new Date(weekStart);
        date.setDate(date.getDate() + (direction * 7));
        const newDate = date.toISOString().split('T')[0];
        
        navigateToWeek(calendar, newDate);
    }
    
    function navigateMonth(calendar, direction) {
        const weekStart = calendar.dataset.weekStart;
        if (!weekStart) return;
        
        const date = new Date(weekStart);
        date.setMonth(date.getMonth() + direction);
        const newDate = date.toISOString().split('T')[0];
        
        navigateToWeek(calendar, newDate);
    }
    
    function navigateToToday(calendar) {
        const today = new Date().toISOString().split('T')[0];
        navigateToWeek(calendar, today);
    }
    
    function navigateToWeek(calendar, date) {
        const url = new URL(window.location.href);
        url.searchParams.set('week_start', date);
        window.history.pushState({}, '', url);
        window.location.href = url.toString();
    }
    
})(jQuery);

