<?php
/**
 * Shortcode Handler for LocalPlus Events
 * 
 * Handles [localplus_events] shortcode
 * 
 * @package LocalPlus_Event_Engine
 */

if (!defined('ABSPATH')) {
    exit;
}

class LocalPlus_Shortcode {
    
    private $api_client;
    private $template_renderer;
    
    /**
     * Constructor
     */
    public function __construct($api_client) {
        $this->api_client = $api_client;
        $this->template_renderer = new LocalPlus_Template_Renderer();
        
        add_shortcode('localplus_events', array($this, 'render_shortcode'));
    }
    
    /**
     * Render shortcode
     * 
     * @param array $atts Shortcode attributes
     * @return string Rendered HTML
     */
    public function render_shortcode($atts) {
        // Parse attributes
        $atts = shortcode_atts(array(
            'limit' => 10,
            'status' => 'published',
            'category' => '',
            'business_type' => '',
            'upcoming' => 'false',
            'sort_by' => 'start_time',
            'sort_order' => 'asc',
        ), $atts, 'localplus_events');
        
        // Build filters
        $filters = array();
        
        if (!empty($atts['status'])) {
            $filters['status'] = $atts['status'];
        }
        
        if (!empty($atts['category'])) {
            $filters['eventType'] = $atts['category'];
        }
        
        if (!empty($atts['business_type'])) {
            $filters['businessType'] = $atts['business_type'];
        }
        
        if ($atts['upcoming'] === 'true') {
            $filters['onlyUpcoming'] = true;
            $filters['startDate'] = date('c'); // Current date
        }
        
        if (!empty($atts['limit'])) {
            $filters['limit'] = intval($atts['limit']);
        }
        
        if (!empty($atts['sort_by'])) {
            $filters['sortBy'] = $atts['sort_by'];
        }
        
        if (!empty($atts['sort_order'])) {
            $filters['sortOrder'] = $atts['sort_order'];
        }
        
        // Get events from API
        $events = $this->api_client->get_events($filters);
        
        // Handle errors
        if (is_wp_error($events)) {
            return '<p class="localplus-events-error">' . esc_html($events->get_error_message()) . '</p>';
        }
        
        if (empty($events)) {
            return '<p class="localplus-events-empty">' . __('No events found.', 'localplus-events') . '</p>';
        }
        
        // Render template
        ob_start();
        $this->template_renderer->render_events_list($events, $atts);
        return ob_get_clean();
    }
}

