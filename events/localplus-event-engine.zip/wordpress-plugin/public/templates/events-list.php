<?php
/**
 * Default Events List Template
 * 
 * This template can be overridden in your theme:
 * /themes/yourtheme/localplus/events-list.php
 * 
 * @package LocalPlus_Event_Engine
 */

if (!defined('ABSPATH')) {
    exit;
}

// Extract events from template variables
$events = isset($events) ? $events : array();
$atts = isset($atts) ? $atts : array();
?>

<div class="localplus-events-list">
    <?php if (empty($events)) : ?>
        <p class="localplus-events-empty"><?php esc_html_e('No events found.', 'localplus-events'); ?></p>
    <?php else : ?>
        <div class="localplus-events-grid">
            <?php foreach ($events as $event) : ?>
                <div class="localplus-event-card" data-event-id="<?php echo esc_attr($event['id']); ?>">
                    <?php if (!empty($event['hero_image_url'])) : ?>
                        <div class="localplus-event-image">
                            <img src="<?php echo esc_url($event['hero_image_url']); ?>" alt="<?php echo esc_attr($event['title']); ?>">
                        </div>
                    <?php endif; ?>
                    
                    <div class="localplus-event-content">
                        <h3 class="localplus-event-title">
                            <?php echo esc_html($event['title']); ?>
                        </h3>
                        
                        <?php if (!empty($event['subtitle'])) : ?>
                            <p class="localplus-event-subtitle">
                                <?php echo esc_html($event['subtitle']); ?>
                            </p>
                        <?php endif; ?>
                        
                        <div class="localplus-event-date">
                            <strong><?php esc_html_e('Date:', 'localplus-events'); ?></strong>
                            <?php 
                            $start_date = new DateTime($event['start_time']);
                            $end_date = new DateTime($event['end_time']);
                            echo esc_html($start_date->format('F j, Y g:i A'));
                            if ($start_date->format('Y-m-d') !== $end_date->format('Y-m-d')) {
                                echo ' - ' . esc_html($end_date->format('F j, Y g:i A'));
                            } else {
                                echo ' - ' . esc_html($end_date->format('g:i A'));
                            }
                            ?>
                        </div>
                        
                        <?php if (!empty($event['location']) || !empty($event['venue_area'])) : ?>
                            <div class="localplus-event-location">
                                <strong><?php esc_html_e('Location:', 'localplus-events'); ?></strong>
                                <?php echo esc_html($event['venue_area'] ?: $event['location']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['description'])) : ?>
                            <div class="localplus-event-description">
                                <?php echo wp_kses_post(wp_trim_words($event['description'], 30)); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['event_type'])) : ?>
                            <span class="localplus-event-category">
                                <?php echo esc_html($event['event_type']); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
.localplus-events-list {
    margin: 20px 0;
}

.localplus-events-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.localplus-event-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.localplus-event-image img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.localplus-event-content {
    padding: 15px;
}

.localplus-event-title {
    margin: 0 0 10px 0;
    font-size: 1.2em;
    font-weight: bold;
}

.localplus-event-subtitle {
    color: #666;
    margin: 0 0 10px 0;
}

.localplus-event-date,
.localplus-event-location {
    margin: 8px 0;
    font-size: 0.9em;
}

.localplus-event-description {
    margin: 10px 0;
    color: #555;
}

.localplus-event-category {
    display: inline-block;
    padding: 4px 8px;
    background: #0073aa;
    color: #fff;
    border-radius: 4px;
    font-size: 0.85em;
    margin-top: 10px;
}

.localplus-events-empty {
    text-align: center;
    padding: 40px;
    color: #666;
}
</style>

