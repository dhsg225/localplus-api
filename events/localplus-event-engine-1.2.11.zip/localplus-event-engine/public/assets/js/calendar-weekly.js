/**
 * Weekly Calendar View JavaScript
 * [2026-02-02] Enhanced with Speed Scroller and Premium UX
 */

(function ($) {
    'use strict';

    $(document).ready(function () {
        initWeeklyView();
    });

    function initWeeklyView() {
        const weeklyCalendars = document.querySelectorAll('.localplus-calendar-weekly');

        weeklyCalendars.forEach(calendar => {
            const prevWeekBtn = calendar.querySelector('.localplus-nav-prev-week');
            const nextWeekBtn = calendar.querySelector('.localplus-nav-next-week');
            const scrollerTrigger = calendar.querySelector('.localplus-speed-scroller-trigger');
            const scrollerDropdown = calendar.querySelector('.localplus-speed-scroller-dropdown');
            const scrollerHeader = calendar.querySelector('.localplus-scroller-header');
            const scrollerFooter = calendar.querySelector('.localplus-scroller-footer');

            // Previous/Next Week Navigation
            if (prevWeekBtn) {
                prevWeekBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    navigateWeek(calendar, -1);
                });
            }

            if (nextWeekBtn) {
                nextWeekBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    navigateWeek(calendar, 1);
                });
            }

            // Day Card Click (Style 2 filtering)
            const dayCards = calendar.querySelectorAll('.localplus-day-card');
            const listSections = calendar.querySelectorAll('.localplus-day-list-section');

            dayCards.forEach(card => {
                card.addEventListener('click', function (e) {
                    e.preventDefault();
                    const targetDate = this.dataset.date;
                    const style = calendar.dataset.weekStyle;

                    // If in Style 1 (Grid), we might just scroll or do nothing
                    // If in Style 2 (List), we filter
                    if (style == '2') {
                        // Update active state
                        dayCards.forEach(c => c.classList.remove('active'));
                        this.classList.add('active');

                        // Show/Hide sections
                        listSections.forEach(section => {
                            if (section.dataset.date === targetDate) {
                                section.style.display = 'block';
                            } else {
                                section.style.display = 'none';
                            }
                        });
                    }
                });
            });

            // Speed Scroller Toggle
            if (scrollerTrigger && scrollerDropdown) {
                scrollerTrigger.addEventListener('click', function (e) {
                    e.stopPropagation();
                    scrollerDropdown.classList.toggle('active');
                });

                // Close dropdown when clicking outside
                document.addEventListener('click', function (e) {
                    if (!calendar.contains(e.target) || (!scrollerDropdown.contains(e.target) && e.target !== scrollerTrigger)) {
                        scrollerDropdown.classList.remove('active');
                    }
                });

                // Scroller Header (scroll up)
                if (scrollerHeader) {
                    scrollerHeader.addEventListener('click', function (e) {
                        e.preventDefault();
                        scrollDropdown(scrollerDropdown, -1);
                    });
                }

                // Scroller Footer (scroll down)
                if (scrollerFooter) {
                    scrollerFooter.addEventListener('click', function (e) {
                        e.preventDefault();
                        scrollDropdown(scrollerDropdown, 1);
                    });
                }

                // Week selection from dropdown
                const scrollerItems = scrollerDropdown.querySelectorAll('.localplus-scroller-item');
                scrollerItems.forEach(item => {
                    item.addEventListener('click', function (e) {
                        e.preventDefault();
                        const targetDate = this.dataset.date;
                        if (targetDate) {
                            navigateToWeek(calendar, targetDate);
                        }
                    });
                });
            }

            // Initialize lightbox for event items
            const eventItems = calendar.querySelectorAll('.localplus-event-lightbox');
            eventItems.forEach(item => {
                if (item.dataset.lightboxInitialized !== 'true') {
                    item.dataset.lightboxInitialized = 'true';
                    item.addEventListener('click', function (e) {
                        e.preventDefault();
                        const eventData = this.dataset.eventData;
                        if (eventData) {
                            try {
                                const event = JSON.parse(eventData);
                                if (typeof openLightbox === 'function') {
                                    openLightbox(event);
                                }
                            } catch (e) {
                                console.error('LocalPlus Events: Error parsing event data:', e);
                            }
                        }
                    });
                }
            });
        });
    }

    function scrollDropdown(dropdown, direction) {
        const scrollAmount = 100;
        dropdown.scrollBy({
            top: direction * scrollAmount,
            behavior: 'smooth'
        });
    }

    function navigateWeek(calendar, direction) {
        const weekStart = calendar.dataset.weekStart;
        if (!weekStart) return;

        const date = new Date(weekStart);
        date.setDate(date.getDate() + (direction * 7));
        const newDate = date.toISOString().split('T')[0];

        navigateToWeek(calendar, newDate);
    }

    function navigateToWeek(calendar, date) {
        const url = new URL(window.location.href);
        url.searchParams.set('week_start', date);
        window.history.pushState({}, '', url);
        window.location.href = url.toString();
    }

})(jQuery);
