/**
 * Table Week Calendar View JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        initTableWeekView();
    });
    
    function initTableWeekView() {
        const tableWeekCalendars = document.querySelectorAll('.localplus-calendar-table-week');
        
        tableWeekCalendars.forEach(calendar => {
            const prevWeekBtn = calendar.querySelector('.localplus-nav-prev-week');
            const nextWeekBtn = calendar.querySelector('.localplus-nav-next-week');
            
            if (prevWeekBtn) {
                prevWeekBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateWeek(calendar, -1);
                });
            }
            
            if (nextWeekBtn) {
                nextWeekBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    navigateWeek(calendar, 1);
                });
            }
            
            // Initialize lightbox for event items
            const eventItems = calendar.querySelectorAll('.localplus-event-lightbox');
            eventItems.forEach(item => {
                if (item.dataset.lightboxInitialized !== 'true') {
                    item.dataset.lightboxInitialized = 'true';
                    item.addEventListener('click', function(e) {
                        e.preventDefault();
                        const eventData = this.dataset.eventData;
                        if (eventData) {
                            try {
                                const event = JSON.parse(eventData);
                                if (typeof openLightbox === 'function') {
                                    openLightbox(event);
                                }
                            } catch (e) {
                                console.error('LocalPlus Events: Error parsing event data:', e);
                            }
                        }
                    });
                }
            });
        });
    }
    
    function navigateWeek(calendar, direction) {
        const weekStart = calendar.dataset.weekStart;
        if (!weekStart) return;
        
        const date = new Date(weekStart);
        date.setDate(date.getDate() + (direction * 7));
        const newDate = date.toISOString().split('T')[0];
        
        navigateToWeek(calendar, newDate);
    }
    
    function navigateToWeek(calendar, date) {
        const url = new URL(window.location.href);
        url.searchParams.set('table_week_start', date);
        window.history.pushState({}, '', url);
        window.location.href = url.toString();
    }
    
})(jQuery);

