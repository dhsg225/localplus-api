/**
 * Frontend JavaScript for LocalPlus Events
 * 
 * @package LocalPlus_Event_Engine
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Get display method from container
        const container = document.querySelector('.localplus-events-list');
        if (!container) return;
        
        const displayMethod = container.dataset.displayMethod || 'eventcard';
        
        // Initialize based on display method
        switch(displayMethod) {
            case 'lightbox':
                initLightbox();
                break;
            case 'eventcard':
                initEventCard();
                break;
            case 'tooltip':
                initTooltip();
                break;
            case 'singlepage':
                // No JS needed, links handle it
                break;
            case 'tiles':
            case 'map':
            case 'slider':
                // These require addons - show message if needed
                console.log('Display method "' + displayMethod + '" requires an addon.');
                break;
        }
        
        // Lazy load images
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            observer.unobserve(img);
                        }
                    }
                });
            });
            
            document.querySelectorAll('.localplus-event-image[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    });
    
    /**
     * Initialize Lightbox modal
     */
    function initLightbox() {
        let modal = document.getElementById('localplus-event-modal');
        if (!modal) {
            console.warn('LocalPlus Events: Modal element not found');
            return;
        }
        
        // Move modal to body level to avoid parent container overflow/positioning issues
        if (modal.parentElement !== document.body) {
            console.log('LocalPlus Events: Moving modal to body level');
            document.body.appendChild(modal);
        }
        
        const closeBtn = modal.querySelector('.localplus-modal-close');
        const eventCards = document.querySelectorAll('.localplus-event-lightbox');
        
        console.log('LocalPlus Events: Initializing lightbox, found', eventCards.length, 'cards');
        
        // Open modal on card click
        eventCards.forEach(card => {
            card.addEventListener('click', function(e) {
                // Don't open if clicking on a link or button
                if (e.target.tagName === 'A' || e.target.closest('a')) {
                    return;
                }
                
                e.preventDefault();
                e.stopPropagation();
                
                const eventData = this.dataset.eventData;
                if (eventData) {
                    try {
                        const event = JSON.parse(eventData);
                        console.log('LocalPlus Events: Opening lightbox for event:', event.title);
                        openLightbox(event);
                    } catch (e) {
                        console.error('LocalPlus Events: Error parsing event data:', e);
                    }
                } else {
                    console.warn('LocalPlus Events: No event data found on card');
                }
            });
        });
        
        // Close handlers
        if (closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                closeLightbox();
            });
        }
        
        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.classList.contains('show')) {
                closeLightbox();
            }
        });
        
        // Close on overlay click (click outside modal container)
        modal.addEventListener('click', function(e) {
            if (e.target === modal || e.target.classList.contains('localplus-modal-wrapper')) {
                closeLightbox();
            }
        });
    }
    
    /**
     * Initialize EventCard slide-down
     */
    function initEventCard() {
        const eventCards = document.querySelectorAll('.localplus-event-card-toggle');
        
        eventCards.forEach(card => {
            card.addEventListener('click', function(e) {
                if (e.target.tagName === 'A' || e.target.closest('a')) {
                    return;
                }
                
                // Toggle active state
                const isActive = this.classList.contains('active');
                
                // Close all other cards
                eventCards.forEach(c => {
                    if (c !== this) {
                        c.classList.remove('active');
                    }
                });
                
                // Toggle this card
                if (!isActive) {
                    this.classList.add('active');
                    // Scroll into view if needed
                    setTimeout(() => {
                        const panel = this.querySelector('.localplus-event-details-panel');
                        if (panel) {
                            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    }, 300);
                } else {
                    this.classList.remove('active');
                }
            });
        });
    }
    
    /**
     * Initialize Tooltip
     */
    function initTooltip() {
        const tooltip = document.getElementById('localplus-event-tooltip');
        if (!tooltip) return;
        
        const eventCards = document.querySelectorAll('.localplus-event-tooltip-trigger');
        
        eventCards.forEach(card => {
            const eventData = card.dataset.eventData;
            if (!eventData) return;
            
            let event;
            try {
                event = JSON.parse(eventData);
            } catch (e) {
                return;
            }
            
            card.addEventListener('mouseenter', function(e) {
                showTooltip(tooltip, event, e);
            });
            
            card.addEventListener('mouseleave', function() {
                hideTooltip(tooltip);
            });
            
            card.addEventListener('mousemove', function(e) {
                positionTooltip(tooltip, e);
            });
        });
    }
    
    /**
     * Show tooltip
     */
    function showTooltip(tooltip, event, e) {
        const startDate = new Date(event.start_time);
        const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: 'numeric', minute: '2-digit', hour12: true };
        
        const dateStr = startDate.toLocaleDateString('en-US', dateOptions);
        const timeStr = startDate.toLocaleTimeString('en-US', timeOptions);
        const location = event.venue_area || event.location || 'Location TBA';
        
        tooltip.innerHTML = `
            <strong>${event.title || ''}</strong><br>
            <small>${dateStr} • ${timeStr}</small><br>
            <small>📍 ${location}</small>
        `;
        
        tooltip.classList.add('active');
        positionTooltip(tooltip, e);
    }
    
    /**
     * Position tooltip
     */
    function positionTooltip(tooltip, e) {
        const x = e.clientX + 15;
        const y = e.clientY + 15;
        
        tooltip.style.left = x + 'px';
        tooltip.style.top = y + 'px';
    }
    
    /**
     * Hide tooltip
     */
    function hideTooltip(tooltip) {
        tooltip.classList.remove('active');
    }
    
    /**
     * Open lightbox modal
     */
    function openLightbox(event) {
        const modal = document.getElementById('localplus-event-modal');
        if (!modal) {
            console.error('LocalPlus Events: Modal element not found in DOM');
            return;
        }
        
        console.log('LocalPlus Events: Opening lightbox modal');
        console.log('LocalPlus Events: Modal element found:', modal);
        
        // Format date/time
        const startDate = new Date(event.start_time);
        const endDate = new Date(event.end_time);
        const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: 'numeric', minute: '2-digit', hour12: true };
        
        const dateStr = startDate.toLocaleDateString('en-US', dateOptions);
        const timeStr = startDate.toLocaleTimeString('en-US', timeOptions) + ' - ' + 
                      endDate.toLocaleTimeString('en-US', timeOptions);
        
        // Populate modal header
        const dateBadge = modal.querySelector('.localplus-modal-date-badge');
        const title = modal.querySelector('.localplus-modal-title');
        const subtitle = modal.querySelector('.localplus-modal-subtitle');
        const headerTime = modal.querySelector('.localplus-modal-header-time');
        const headerLocation = modal.querySelector('.localplus-modal-header-location');
        
        if (dateBadge) dateBadge.textContent = dateStr;
        if (title) title.textContent = event.title || '';
        if (subtitle) subtitle.textContent = event.subtitle || '';
        if (headerTime) headerTime.textContent = timeStr;
        if (headerLocation) headerLocation.textContent = event.venue_area || event.location || 'Location TBA';
        
        // Populate modal image
        const modalImage = modal.querySelector('.localplus-modal-image');
        const imageWrapper = modal.querySelector('.localplus-modal-image-wrapper');
        if (event.hero_image_url && modalImage && imageWrapper) {
            modalImage.src = event.hero_image_url;
            modalImage.alt = event.title || '';
            imageWrapper.style.display = 'block';
        } else if (imageWrapper) {
            imageWrapper.style.display = 'none';
        }
        
        // Populate modal body
        const description = modal.querySelector('.localplus-modal-description');
        if (description) {
            description.textContent = event.full_description || event.description || 'No description available.';
        }
        
        // Populate Organizer
        const organizer = modal.querySelector('.localplus-modal-organizer');
        if (organizer) {
            const organizerName = event.organizer || event.organizer_name || event.created_by_name || 'Not specified';
            organizer.textContent = organizerName;
        }
        
        // Populate Map
        const mapContainer = modal.querySelector('.localplus-modal-map');
        if (mapContainer) {
            const location = event.venue_area || event.location || '';
            const latitude = event.venue_latitude || event.latitude || event.lat || null;
            const longitude = event.venue_longitude || event.longitude || event.lng || event.lon || null;
            
            if (latitude && longitude) {
                // Create embedded Google Maps iframe (public embed URL, no API key required)
                const mapEmbedUrl = `https://www.google.com/maps?q=${latitude},${longitude}&hl=en&z=14&output=embed`;
                const mapLinkUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
                mapContainer.innerHTML = `
                    <div class="localplus-modal-map-embed">
                        <iframe 
                            src="${mapEmbedUrl}" 
                            width="100%" 
                            height="300" 
                            style="border:0; border-radius: 4px;" 
                            allowfullscreen="" 
                            loading="lazy" 
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                    <a href="${mapLinkUrl}" target="_blank" rel="noopener noreferrer" class="localplus-modal-map-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <span>Open in Google Maps</span>
                    </a>
                    ${location ? `<p class="localplus-modal-map-location">${location}</p>` : ''}
                `;
            } else if (location) {
                // Show location search with embedded map (public embed URL, no API key required)
                const searchUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
                const mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(location)}&hl=en&z=14&output=embed`;
                mapContainer.innerHTML = `
                    <div class="localplus-modal-map-embed">
                        <iframe 
                            src="${mapEmbedUrl}" 
                            width="100%" 
                            height="300" 
                            style="border:0; border-radius: 4px;" 
                            allowfullscreen="" 
                            loading="lazy" 
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                    <a href="${searchUrl}" target="_blank" rel="noopener noreferrer" class="localplus-modal-map-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <span>Open ${location} in Google Maps</span>
                    </a>
                `;
            } else {
                mapContainer.innerHTML = '<span class="localplus-modal-map-unavailable">Location not available</span>';
            }
        }
        
        // Prevent body scroll (EventOn style)
        document.body.classList.add('localplus-modal-open');
        
        // Force display and add show class
        modal.style.display = 'block';
        modal.style.opacity = '1';
        modal.style.visibility = 'visible';
        modal.classList.add('show');
        modal.setAttribute('aria-hidden', 'false');
        
        // Debug: Check computed styles and parent elements
        const computedStyle = window.getComputedStyle(modal);
        console.log('LocalPlus Events: Modal display:', computedStyle.display);
        console.log('LocalPlus Events: Modal opacity:', computedStyle.opacity);
        console.log('LocalPlus Events: Modal visibility:', computedStyle.visibility);
        console.log('LocalPlus Events: Modal z-index:', computedStyle.zIndex);
        console.log('LocalPlus Events: Modal position:', computedStyle.position);
        console.log('LocalPlus Events: Modal top:', computedStyle.top);
        console.log('LocalPlus Events: Modal left:', computedStyle.left);
        console.log('LocalPlus Events: Modal width:', computedStyle.width);
        console.log('LocalPlus Events: Modal height:', computedStyle.height);
        
        // Check parent elements for overflow/positioning issues
        let parent = modal.parentElement;
        let depth = 0;
        while (parent && depth < 5) {
            const parentStyle = window.getComputedStyle(parent);
            if (parentStyle.overflow === 'hidden' || parentStyle.overflow === 'auto' || 
                parentStyle.position === 'relative' || parentStyle.position === 'absolute') {
                console.log('LocalPlus Events: Parent element at depth', depth, ':', parent.tagName, parent.className, 
                    'overflow:', parentStyle.overflow, 'position:', parentStyle.position);
            }
            parent = parent.parentElement;
            depth++;
        }
        
        // Check if modal is actually in viewport
        const rect = modal.getBoundingClientRect();
        console.log('LocalPlus Events: Modal bounding rect:', {
            top: rect.top,
            left: rect.left,
            width: rect.width,
            height: rect.height,
            visible: rect.width > 0 && rect.height > 0
        });
        
        // Force check if modal is visible
        const isVisible = rect.width > 0 && rect.height > 0 && 
                         rect.top >= 0 && rect.left >= 0 &&
                         rect.top < window.innerHeight && rect.left < window.innerWidth;
        console.log('LocalPlus Events: Modal is visible in viewport:', isVisible);
        console.log('LocalPlus Events: Modal show class added');
        
        // Reset scroll position
        const scrollable = modal.querySelector('.localplus-modal-scrollable');
        if (scrollable) {
            scrollable.scrollTop = 0;
        }
        
        // Focus management
        const closeBtn = modal.querySelector('.localplus-modal-close');
        if (closeBtn) {
            setTimeout(() => closeBtn.focus(), 350);
        }
    }
    
    /**
     * Close lightbox modal
     */
    function closeLightbox() {
        const modal = document.getElementById('localplus-event-modal');
        if (!modal) return;
        
        console.log('LocalPlus Events: Closing lightbox modal');
        
        // Remove show class and force hide
        modal.classList.remove('show');
        modal.style.display = 'none';
        modal.style.opacity = '0';
        modal.style.visibility = 'hidden';
        
        // Restore body scroll after animation
        setTimeout(() => {
            document.body.classList.remove('localplus-modal-open');
            modal.setAttribute('aria-hidden', 'true');
        }, 500);
    }
    
})(jQuery);
